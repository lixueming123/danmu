package com.lxm.danmu.mapper;

import com.lxm.danmu.entity.Msg;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lxm
 * @since 2022-04-22
 */
public interface MsgMapper extends BaseMapper<Msg> {

}
