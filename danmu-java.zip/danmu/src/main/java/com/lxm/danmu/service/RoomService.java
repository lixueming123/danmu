package com.lxm.danmu.service;

import com.lxm.danmu.entity.Room;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lxm
 * @since 2022-04-22
 */
public interface RoomService extends IService<Room> {

}
