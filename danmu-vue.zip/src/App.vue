<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>

<script>

    export default {
        name: 'App',
        components: {}
    }
</script>

<style>
    * {
        box-sizing: border-box;
        margin: 0;
        /*font-family: "Microsoft JhengHei";*/
        /* padding: 0; */
    }
</style>
