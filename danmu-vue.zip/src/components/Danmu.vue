<template>
	<div id="danmu" :class="{'transition':(this.position===0)}" :style="{'left':this.left+'px','top':this.top+'px'}" ref="dan">
		<div style="position: relative;width: 100%;">
			<span :class="{'decoration':this.type}" :style="{color:this.color,'font-size':this.size+'px',
			'font-weight':this.bold,'font-style':this.italic}">
				{{this.content}}</span>
		</div>
	</div>
</template>

<script>
	export default {
		name: "Danmu",
		props: ["id", "content", "color", "bold", "italic", "position", "size", "type", "width", "height"],
		data() {
			return {
				'left': this.width,
				'top': this.height
			}
		},
		created() {
			// console.log(this.position)
			const _this = this;
			var danWidth;
			var danHeight;
			//弹幕生成速度需时间，以免ref获取为undefined
			window.setTimeout(function() {
				danWidth = _this.$refs.dan.offsetWidth    //弹幕的宽
				danHeight = _this.$refs.dan.offsetHeight  //弹幕的高
				//0指弹幕位置随机
				if (_this.position === 0) {
					_this.top = Math.ceil(Math.random() * (_this.top - 60 - danHeight));
					_this.left = - danWidth
				} else if (_this.position === 1) {    //1为固定顶部居中
					_this.top = 5
					_this.left = (_this.width-danWidth)/2     //居中
				} else {  //2为固定底部居中
					_this.top = _this.top - 60 - danHeight
					_this.left = (_this.width-danWidth)/2     //居中
				}
			}, 200);
			
			window.setTimeout(function() {
				_this.$emit('deletedan', _this.id)  //调用父级方法去除该弹幕
			}, 15000);
		}
	}
</script>

<style scoped>
	#danmu {
		width: auto;
		height: auto;
		float: left;
		position: absolute;
		white-space:nowrap;
	}

	.decoration {
		text-decoration-line: underline;
	}

	.transition {
		transition-property: left;
		transition-duration: 10s;
		transition-timing-function: linear;

		/*gpu 加速*/
		-webkit-transform: translateZ(0);
		-moz-transform: translateZ(0);
		-ms-transform: translateZ(0);
		-o-transform: translateZ(0);

		-webkit-backface-visibility: hidden;
		backface-visibility: hidden;

	}
</style>
