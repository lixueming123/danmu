<template>
    <div style="text-align: center">
        <span>Copyright 2022 by lixueming</span>
    </div>
</template>

<script>
    export default {
        name: "Footer"
    }
</script>

<style scoped>

</style>