<template>
    <div class="m-content">
        <div>
            <span></span>
            <span><el-link type="info" href="/main">主页</el-link></span>
            <el-divider direction="vertical"></el-divider>
            <span><el-link type="success" @click="addLive()">新建房间</el-link></span>
            <el-divider direction="vertical"></el-divider>
            <span><el-link type="success" href="/mylive">我的房间</el-link></span>
            <el-divider direction="vertical"></el-divider>
            <span v-if="!hasLogin"><el-link type="primary" href="/login">登录</el-link></span>
            <span v-if="hasLogin"><el-link type="danger">用户名：</el-link></span>
            <span v-if="hasLogin"><el-link type="danger">{{user.username}}</el-link></span>
            <el-divider v-if="hasLogin" direction="vertical"></el-divider>
            <span v-if="hasLogin"><el-link type="danger" @click="logout()">退出</el-link></span>
        </div>

        <el-dialog
                title="新建房间"
                :visible.sync="dialog_visible">
            <el-form v-model="addRoom">
                <el-form-item label="房主">
                    <el-input type="text" maxlength="12" v-model="addRoom.username" disabled/>
                </el-form-item>
                <el-form-item label="房间名称">
                    <el-input type="text" maxlength="12" v-model="addRoom.rname"/>
                </el-form-item>
            </el-form>
            <el-button type="primary" @click="doAddLive()">新建</el-button>
        </el-dialog>

    </div>


</template>

<script>

    export default {
        name: "Header",
        data() {
            return {
                user: {
                    username: '请先登录',
                },
                hasLogin: false,
                dialog_visible: false,
                addRoom: {
                    username: '',
                    rname: ''
                }
            }
        },
        methods: {
            logout() {
                const _this = this
                this.$axios.get("/user/logout").then(res => {
                    _this.$store.commit("remove_info")
                    _this.hasLogin = false
                    _this.$router.push("/login")
                })
            },
            addLive() {
                this.dialog_visible = true;
            },
            doAddLive() {
                const _this = this;
                this.$axios.post("/room/newLive", _this.addRoom).then(resp =>{

                    _this.$message.success("创建成功")
                    _this.$parent.rooms.unshift(resp.data.obj)
                    console.log(_this.$parent.rooms);
                    _this.dialog_visible = false;

                })
            }
        },
        created() {
            if (this.$store.getters.get_user.username) {
                this.user.username = this.$store.getters.get_user.username
                this.hasLogin = true;
                this.addRoom.username = this.user.username
                console.log(this.$store.getters.get_user)
            }
        }
    }
</script>

<style scoped>
    .m-content {
        max-width: 1000px;
        margin: 0 auto;
        text-align: center;
    }
</style>