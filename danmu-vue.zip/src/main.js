import Vue from 'vue'
import App from './App.vue'
import router from './router.js'
import axios from 'axios'
import Element from 'element-ui'
import store from './store'

// import Barrage from "vue-custom-barrage";
import ChatMessage from './ChatMessage_pb.js'
import 'element-ui/lib/theme-chalk/index.css'

import './axios'

Vue.prototype.$axios = axios
Vue.prototype.ChatMessage = ChatMessage

Vue.config.productionTip = false

Vue.use(Element)
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
