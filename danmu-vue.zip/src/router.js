/* eslint-disable */
import Vue from 'vue'
import Room from './views/Room'
import Main from "./views/Main";
import Login from "./views/Login"
import MyLive from "./views/MyLive"
import VueRouter from "vue-router";

Vue.use(VueRouter)

const routes = [
    {
        path:'/',
        name: 'Index',
        redirect: {
            name: 'Main'
        }
    },
    {
      path: "/main",
      name: 'Main',
      component: Main
    },
    {
        path:'/room/:roomId',
        name: 'Room',
        component: Room
    },
    {
        path: '/login',
        name: 'Login',
        component: Login
    },
    {
        path: "/mylive",
        name: 'MyLive',
        component: MyLive
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router
