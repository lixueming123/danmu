import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        userInfo: JSON.parse(localStorage.getItem("userInfo"))
    },
    mutations: {
        set_user: (state, userInfo) => {
            state.userInfo = userInfo;
            sessionStorage.setItem("userInfo", JSON.stringify(userInfo));
            localStorage.setItem("userInfo", JSON.stringify(userInfo))
        },
        remove_info: state => {
            state.userInfo = {};
            sessionStorage.setItem("userInfo", JSON.stringify({}));
            localStorage.setItem("userInfo", JSON.stringify({}))
        }

    },
    getters: {
        // get
        get_user: state => {
            return state.userInfo;
        }
    },
    actions: {
    },
    modules: {
    }
})