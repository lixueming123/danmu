import 'ChatMessage_pb.js'

let Websocket = require('ws')

let ws = new Websocket("ws://localhost:7000/1/groupchat");
ws.binaryType = 'arraybuffer'

function getTime () {
    const time = new Date()
    var t = time.getFullYear() + '-' + (time.getMonth() + 1) + '-' + time.getDate() +
        " " + time.getHours() + ':' + time.getMinutes() + ':';
    if (time.getSeconds() < 10) t += '0';
    t += time.getSeconds();
    return t;
}

ws.onopen = function () {
    // Web Socket 已连接上，使用 send() 方法发送数据
    setInterval(function sendMsg() {
        let message = {
            content: "哈哈哈",
            size: 30,
            color: '#000',
            bold: false,
            italic: false,
            position: 0,
            // ip: '127.0.0.1',
            name: "test",
            time: '',
            available: 1,
            rid: 0
        }
        const msg = new proto.request()
        msg.setSize(message.size)
        msg.setColor(message.color)
        msg.setBold(message.bold)
        msg.setItalic(message.italic)
        msg.setPosition(message.position)
        msg.setName(message.name)
        msg.setTime(getTime())
        msg.setAvailable(message.available)
        msg.setRid(message.rid)

        const bit = msg.serializeBinary()
        ws.send(bit)
    }, 20)

    // console.log("数据发送中...");
};
ws.onmessage = function (e) {
    // console.log("接受到消息:"+e.data);
    // createEle(e.data);
};
ws.onclose = function () {
    // 关闭 websocket
    // console.log("连接已关闭...");
};
