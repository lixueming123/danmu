<template>
    <div>
        <Header></Header>
        <el-timeline>
            <el-timeline-item :timestamp="room.time" placement="top" v-for="(room, index) in rooms" :key="index">
                <el-card>
                    <router-link :to="{name: 'Room', params: {roomId: room.id}}">
                        <h4>{{room.rname}}</h4>
                    </router-link>

                    <p>房主：{{room.username}}</p>
                </el-card>
            </el-timeline-item>

        </el-timeline>

        <el-pagination class="m-page"
                       background
                       style="text-align: center"
                       layout="prev, pager, next"
                       :pagesize="pageInfo.pageSize"
                       :current-page="pageInfo.currentPage"
                       :total="pageInfo.total + (pageInfo.total - 1)"
                       @current-change=page
        >
        </el-pagination>
    </div>
</template>

<script>
    import Header from "../components/Header";
    export default {
        name: "Main",
        components: {Header},
        data() {
            return {
                rooms: [],
                pageInfo: {
                    currentPage: 1,
                    pageSize: 5,
                    pages: 1,
                    total: 1,

                }
            }
        },
        methods: {
            page(currentPage) {
                const _this = this;
                _this.$axios.get("/room/list?currentPage=" + currentPage).then(res => {
                    const data = res.data.obj;

                    this.rooms = data.records

                    this.pageInfo.currentPage = data.current
                    this.pageInfo.total = data.total
                    this.pageInfo.pages = data.pages
                    this.pageInfo.pageSize = data.size
                    console.log(this.pageInfo)
                })
            }
        },
        created() {
            this.page(1)
        }
    }
</script>

<style scoped>

</style>