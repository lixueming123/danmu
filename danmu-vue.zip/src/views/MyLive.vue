<template>
    <div>
        <Header></Header>
        <el-timeline>
            <el-timeline-item :timestamp="room.time" placement="top" v-for="(room,index) in rooms" :key="index">
                <el-card>
                    <router-link :to="{name: 'Room', params: {roomId: room.id}}">
                        <h4>{{room.rname}}</h4>
                    </router-link>

                    <p>房主：{{room.username}}</p>
                </el-card>
            </el-timeline-item>

        </el-timeline>

    </div>
</template>

<script>
    import Header from "../components/Header";
    export default {
        name: "MyLive",
        components: {Header},
        data() {
            return {
                rooms: [],
                pageInfo: {
                    currentPage: 1,
                    pageSize: 5,
                    pages: 1,
                    total: 1,

                }
            }
        },
        methods: {
            page(currentPage) {
                const _this = this;
                _this.$axios.get("/room/myLive").then(res => {
                    this.rooms = res.data.obj;


                    this.pageInfo.currentPage = res.data.obj.current
                    this.pageInfo.total = res.data.obj.total
                    this.pageInfo.pages = res.data.obj.pages
                    this.pageInfo.pageSize = res.data.obj.size
                    console.log(this.pageInfo)
                })
            }
        },
        created() {
            this.page(1)
        }
    }
</script>

<style scoped>

</style>