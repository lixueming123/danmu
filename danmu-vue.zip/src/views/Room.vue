<template>
	<div id="frame">
		<Header></Header>
		<div id="chat" ref="chatbox">
			<div class="head">
				<h1 align="center"> {{room.rname}} </h1>
			</div>
			<div class="message-body">
				<Message v-for="message in messages" :key="message.id" :name="message.name" :time="message.time" :content="message.content"
				 :type="message.type"></Message>
			</div>
		</div>
		<div id="danmu-frame" ref="danmuref">
			<div style="position: relative;z-index: 10;">
				<Danmu v-for="dan in danmus" :key="dan.id" :id="dan.id" :content="dan.content" :color="dan.color" :bold="dan.bold"
				 :position="dan.position" :size="dan.size" :italic="dan.italic" :width="dan.width" :height="dan.height" :type="dan.type"
				 @deletedan='deleteDanmu'></Danmu>
			</div>
			<div class="input">
				<div style="width: 100%;">
					<form action="" style="display: flex;justify-content: space-around;font-size: 17px;">
						<div>
							<span>字体大小：</span>
							<select v-model="message.size">
								<option value="20" checked="checked">小</option>
								<option value="25">中</option>
								<option value="30">大</option>
							</select>
						</div>
						
						<div>
							<span>字体颜色：</span>
							<select v-model="message.color">
								<option value="#000" checked="checked">黑</option>
								<option value="red">红</option>
								<option value="yellow">黄</option>
								<option value="blue">蓝</option>
								<option value="green">绿</option>
							</select>
						</div>
						
						<div>
							<span>弹幕位置：</span>
							<select v-model="message.position">
								<option value="0" checked="checked">随机</option>
								<option value="1">顶端</option>
								<option value="2">底部</option>
							</select>
						</div>
						
						<div>
							<span>加粗：</span>
							<input type="checkbox" v-model="message.bold" />
						</div>
						
						<div>
							<span>斜体：</span>
							<input type="checkbox" v-model="message.italic" />
						</div>
						
						<div>
							<span>昵称：</span>
							<input class="form-input" @keyup.enter="send()" v-model="message.name" type="text" maxlength="16" disabled />
						</div>
						
						<div>
							<span>内容：</span>
							<input class="form-input" @keyup.enter="send()" v-model="message.content" type="text" maxlength="32" />
						</div>
						
						<div>
							<input class="form-input" @click="send()" type="button" value="发送" required="required" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import Header from "../components/Header.vue";
	var socket;
	var time = new Date()
	import Message from '../components/Message.vue'
	import Danmu from '../components/Danmu.vue'
	const uuid = require('uuid')
	//websocket服务器的地址  ws://ip:端口/netty_context_path
	const ip = "127.0.0.1"      		//后端ip地址
	const netty_port = 7000      		//和后端保持一致
	const context_path = "/groupchat"   //和后端保持一致

	export default {
		name: "Room",
		components: {
			Header,
			Message,
			Danmu
		},
		data() {
			return {
				message: {
					content: "",
					size: 30,
					color: '#000',
					bold: false,
					italic: false,
					position: 0,
					// ip: '127.0.0.1',
					name: "童鞋",
					time: '',
					available: 1,
					rid: 0
				},
				sendnum: 0,
				messages: [],
				danmus: [],
				room: {}
			}
		},
		created() {
			this.message.rid = this.$route.params.roomId
			if (this.$store.getters.get_user.username) {
				this.message.name = this.$store.getters.get_user.username
			}

			const _this = this
			_this.getRoomInfo()
			//判断当前的浏览器是否支持 websocket
			if (window.WebSocket) {
				//go on
				socket = new WebSocket("ws://"+ip+":"+netty_port+"/"+ this.message.rid + context_path)
				socket.binaryType = 'arraybuffer'

				//相当于channelRead0，ev收到服务器·端回送的消息
				socket.onmessage = function(ev) {
					let data = proto.response.deserializeBinary(ev.data)
					_this.addMessage(data, 0)
					_this.addDanmu(data, 0)
				}
				//相当于连接开启
				socket.onopen = function(ev) {
					console.log("连接开启了...");
					//rt.value = "连接开启了..."
				}

				//感知到连接关闭
				socket.onclose = function(ev) {
					console.log("连接关闭了...");
					// rt.value = rt.value + "\n" + "连接关闭了..."
				}
			} else {
				alert("当前的浏览器不支持websocket");
			}
		},
		methods: {
			//消息框滑轮触底
			scrollToBottom() {
				const _this = this
				window.setTimeout(function() {
					_this.$refs.chatbox.scrollTop = 100000000
				}, 100);
			},
			checkLogin() {
				if (this.$store.getters.get_user.username) return true
				return false
			},
			send() {
				if (!this.checkLogin()) {
					this.$message.error("用户未登录")
					return
				}

				const _this = this
				if (socket.readyState === WebSocket.OPEN) {
					this.message.content = this.message.content.replace(/^\s*|\s*$/g,"");  //内容去首尾空格
					this.message.name = this.message.name.replace(/^\s*|\s*$/g,"");    //昵称去首尾空格
					if (this.message.content !== '' && this.message.name !=='') {
						this.message.time = this.getTime()
						//后端springboot存储弹幕接口地址
						this.$axios.post("/message/save", this.message).then(res => {
							this.message.content = ""
						});
						//通过socket 发送消息
						let msg = new proto.request();

						_this.buildRequest(msg);
						this.addMessage(msg, 1)
						this.addDanmu(msg, 1)
						const bit = msg.serializeBinary()
						console.log(bit)
						socket.send(bit)
					}
				} else {
					alert("连接没有开启")
				}
			},
			getRoomInfo() {
				const _this = this;
				this.$axios.get("/room/" + _this.message.rid).then(res => {
					console.log(res.data)
					_this.room = res.data.obj;
				})
			},
			buildRequest(msg) {
				msg.setAvailable(this.message.available)
				msg.setBold(this.message.bold)
				msg.setColor(this.message.color)
				msg.setContent(this.message.content)
				msg.setItalic(this.message.italic)
				msg.setName(this.message.name)
				msg.setPosition(this.message.position)
				msg.setRid(this.message.rid)
				msg.setSize(this.message.size)
				msg.setTime(this.getTime())
			},
			//添加消息
			addMessage(message, type) {
				let msg = {};
				msg.id = uuid.v4()
				msg.name = message.getName();
				msg.content = message.getContent()
				msg.time = message.getTime()
				msg.type = type
				this.messages.push(msg)
				console.log(this.messages)
				this.scrollToBottom()
			},
			//添加弹幕
			addDanmu(data, type) {
				let danmu = {};
				danmu.id = uuid.v4()
				danmu.content = data.getContent();
				danmu.color = data.getColor();
				danmu.position = data.getPosition()
				danmu.size = data.getSize()
				danmu.type = type
				// console.log(this.$refs.danmuref)
				danmu.width = this.$refs.danmuref.offsetWidth
				danmu.height = this.$refs.danmuref.offsetHeight
				if (data.getBold()) danmu.bold = 'bolder'
				else danmu.bold = 'normal'
				if (data.getItalic()) danmu.italic = 'italic'
				else danmu.italic = 'normal'
				this.danmus.push(danmu)
				console.log(this.danmus)
			},
			//删除弹幕
			deleteDanmu(ids) {
				this.danmus = this.danmus.filter(danmu => danmu.id !== ids)
			},
			//时间格式
			getTime() {
				time = new Date()
				var t = time.getFullYear() + '-' + (time.getMonth() + 1) + '-' + time.getDate() +
					" " + time.getHours() + ':' + time.getMinutes() + ':';
				if (time.getSeconds() < 10) t += '0';
				t += time.getSeconds();
				return t;
			}
		}
	}
</script>
<style scoped>
	#frame {
		width: 100%;
		height: 100%;
		margin: 0 auto;
		position: absolute;
	}

	#chat {
		float: left;
		width: 25%;
		height: 97.1%;
		background-image: url(../assets/bg1.jpg);
		background-repeat: no-repeat;
		background-size: cover;

		overflow-y: scroll;
	}

	#danmu-frame {
		float: left;
		width: 75%;
		height: 90%;
		background-color: #FFF;
		overflow: hidden;
		background-image: url(../assets/bg2.jpg);
		background-repeat: no-repeat;
		background-size: cover;
	}

	.head {
		width: 25%;
		height: 50px;
		overflow: hidden;
		border-bottom: 1px solid #000000;
		background-color: #FAFAD2;
		position: absolute;
	}

	.head-text {
		position: sticky;
	}

	.input {
		position: absolute;
		width: 75%;
		height: auto;
		min-height: 50px;
		bottom: 0;
		background-color: pink;
		overflow: hidden;
		padding: 1%;
		z-index: 20;
	}

	.form-input {
		/* float: left; */
	}

	.message-body {
		padding-top: 60px;
	}
</style>
