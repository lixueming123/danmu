module.exports={
	lintOnSave: false
}